
<!-- 

Template Name: iMedical - Medical, Doctor, Dentist, Clinic and Hospital Template
Version: 1.0.0
Author: CODASTROID
Contact: codastroid@gmail.com
Follow: https://themeforest.net/user/codastroid?ref=codastroid
Template Link: https://themeforest.net/item/health-medical-dentist-doctor-clinic-and-hospital-template-imedical/19747019?ref=CODASTROID
License: You must have a valid license purchased only from themeforest in order to legally use the theme for your project.

-->

<!DOCTYPE html>
<!--[if lt IE 9 ]><html lang="en" dir="ltr" class="no-js ie-old"> <![endif]-->
<!--[if IE 9 ]><html lang="en" dir="ltr" class="no-js ie9"> <![endif]-->
<!--[if IE 10 ]><html lang="en" dir="ltr" class="no-js ie10"> <![endif]-->
<!--[if (gt IE 10)|!(IE)]><!-->
<html lang="en" dir="ltr" class="no-js">
<!--<![endif]-->

<head>

	<!-- ––––––––––––––––––––––––––––––––––––––––– -->
	<!-- META TAGS                                 -->
	<!-- ––––––––––––––––––––––––––––––––––––––––– -->
	<meta charset="utf-8">
	<!-- Always force latest IE rendering engine -->
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<!-- Mobile specific meta -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags --> 

	<!-- ––––––––––––––––––––––––––––––––––––––––– -->
	<!-- PAGE TITLE                                -->
	<!-- ––––––––––––––––––––––––––––––––––––––––– -->
	<title>iMedical - Medical, Doctor, Dentist, Clinic and Hospital Template</title>

	<!-- ––––––––––––––––––––––––––––––––––––––––– -->
	<!-- SEO METAS                                 -->
	<!-- ––––––––––––––––––––––––––––––––––––––––– -->
	<meta name="description" content="brief description here">
	<meta name="keywords" content="insert, keywords, here">
	<meta name="robots" content="index, follow">
    <meta name="author" content="EvenThemes">

	<!-- ––––––––––––––––––––––––––––––––––––––––– -->
	<!-- PAGE FAVICON                              -->
	<!-- ––––––––––––––––––––––––––––––––––––––––– -->
	<link rel="icon" type="image/icon" href="assets/images/favicon/favicon.png">

	<!-- ––––––––––––––––––––––––––––––––––––––––– -->
	<!-- GOOGLE FONTS                              -->
	<!-- ––––––––––––––––––––––––––––––––––––––––– -->
    <link href="https://fonts.googleapis.com/css?family=Dosis:600,700" rel="stylesheet"> 
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:600,700' rel='stylesheet' type='text/css'>


	<!-- ––––––––––––––––––––––––––––––––––––––––– -->
	<!-- Include CSS Filess                        -->
	<!-- ––––––––––––––––––––––––––––––––––––––––– -->

	<!-- Bootstrap -->
	<link href="assets/css/bootstrap.min.css" rel="stylesheet">

	<!-- Font Awesome -->
	<link href="assets/vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">

	<!-- Linearicons -->
    <link href="assets/vendors/linearicons/css/linearicons.css" rel="stylesheet">

    <!-- Webfont Medical Icons -->
	<link href="assets/vendors/webfont-medical-icons/css/wfmi-style.css" rel="stylesheet">

	<!-- Owl Carousel -->
	<link href="assets/vendors/owl-carousel/owl.carousel.min.css" rel="stylesheet">
	<link href="assets/vendors/owl-carousel/owl.theme.min.css" rel="stylesheet">

	<!-- Magnific popup -->
	<link href="assets/vendors/magnific-popup/css/magnific-popup.css" rel="stylesheet">

    <!-- YTPlayer -->
    <link href="assets/vendors/YTPlayer/css/jquery.mb.YTPlayer.min.css" rel="stylesheet">

    <!-- Bootstrap Datepicker -->
    <link rel="stylesheet" type="text/css" href="assets/vendors/bootstrap-datepicker/css/bootstrap.datepicker.css">


	<!-- Template Stylesheet -->
	<link href="assets/css/base.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
	<link href="assets/css/demo.css" rel="stylesheet">
	
</head>
<body id="body" class="wide-layout preloader-active">

	<!-- ––––––––––––––––––––––––––––––––––––––––– -->
	<!-- PRELOADER                                 -->
	<!-- ––––––––––––––––––––––––––––––––––––––––– -->
	<!-- Preloader -->
	<div id="preloader" class="preloader">
		<div class="loader pos-center">
			<img src="assets/images/preloader.gif" alt="">
		</div>
	</div>
	<!-- End Preloader -->

	<!-- ––––––––––––––––––––––––––––––––––––––––– -->
	<!-- WRAPPER                                   -->
	<!-- ––––––––––––––––––––––––––––––––––––––––– -->
	<div id="pageWrapper" class="page-wrapper">
		
		<!-- –––––––––––––––[ HEADER ]––––––––––––––– -->
		<!-- Start Top Bar -->
		<div class="topbar bg-theme">
            <div class="container">
                <div class="row">
                    <div class="col-md-8">
                        <ul class="topbar-info list-inline is-hidden-xs t-xs-center t-md-left">
                        	<li class="prl-10">
                        	<i class="fa fa-map-marker mr-10 font-16"></i>701 Shadow Ln, Las Vegas, NV 89106</li>
                        	<li class="prl-10">
                        	<i class="fa fa-phone mr-10 font-16"></i>1 (800) 233-2742 </li>
                        	<li class="prl-10">
                        	<i class="fa fa-envelope mr-10 font-16"></i>codastroid@gmail.com</li>
                        </ul>
                    </div>
                    <div class="col-md-4">
                    	<ul class="social-icons list-inline font-16  t-xs-center t-md-right is-hidden-sm">
                            <li class="social-icons__item"><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li class="social-icons__item"><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li class="social-icons__item"><a href="#"><i class="fa fa-linkedin"></i></a></li>
                            <li class="social-icons__item"><a href="#"><i class="fa fa-google-plus"></i></a></li>
                            <li class="social-icons__item"><a href="#"><i class="fa fa-pinterest"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <header id="mainHeader" class="main-header">
            <div class="header-menu">
                <div class="container">
                    <div class="row">
                        <div class="col-md-3">
                            <div class="logo">
                                <a href="index.php"><img src="assets/images/logo.png" alt=""></a>
                            </div>
                            <!-- Phone Menu button -->
                            <button id="menu" class="menu is-hidden-md-up"></button>
                        </div>
                        <div class="col-md-9">
                            <nav class="navigation">
                                <ul>
                                    <li><a href="javascript:avoid(0);">Home</a>
                                        <i class="fa fa-plus is-hidden-md-up"></i>
                                        <ul class="sub-nav">
                                            <li> <a href="index.html">Home page 1</a> </li>
                                            <li> <a href="index-02.html">Home page 2</a> </li>
                                        </ul>
                                    </li>
                                    <li><a href="about.html">About us</a></li>
                                    <li><a href="javascript:avoid(0);">Services</a> <i class="fa fa-plus is-hidden-md-up"></i>
                                        <ul class="sub-nav">
                                            <li> <a href="services.html">Services</a> </li>
                                            <li> <a href="service-details.html">Service Details</a> </li>
                                        </ul>
                                    </li>
                                    <li><a href="javascript:avoid(0);">Doctors</a> <i class="fa fa-plus is-hidden-md-up"></i>
                                        <ul class="sub-nav">
                                            <li><a href="doctors-grid.html">Doctors Grid</a></li>
                                            <li><a href="doctors-list.html">Doctors List</a></li>
                                            <li><a href="doctor-details.html">Doctor Details</a> </li>
                                        </ul>
                                    </li>
                                    <li><a href="javascript:avoid(0);">Bolg</a> <i class="fa fa-plus is-hidden-md-up"></i>
                                        <ul class="sub-nav">
                                            <li><a href="blog-classic.html">Blog Classic</a></li>
                                            <li><a href="blog-grid.html">Blog Grid</a></li>
                                            <li><a href="blog-list.html">Blog List</a></li>
                                            <li><a href="blog-single.html">Blog Details</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="javascript:avoid(0);">pages</a> <i class="fa fa-plus is-hidden-md-up"></i>
                                        <ul class="sub-nav">
                                            <li> <a href="appointment.html">Appointment</a> </li>
                                            <li class="sub-menu"> <a href="javascript:avoid(0);">Gallery</a> <i class="fa fa-plus is-hidden-md-up"></i>
                                                <ul class="sub-nav">
                                                    <li> <a href="gallery-01.html">Gallery 1</a> </li>
                                                    <li> <a href="gallery-02.html">Gallery 2</a> </li>
                                                </ul>
                                            </li>
                                            <li class="sub-menu"> <a href="javascript:avoid(0);">Departements</a> <i class="fa fa-plus is-hidden-md-up"></i>
                                                <ul class="sub-nav">
                                                    <li> <a href="departments.html">Departements</a> </li>
                                                    <li> <a href="department-single.html">Single Departement</a> </li>
                                                </ul>
                                            </li>
                                            <li> <a href="pricing-tables.html">Pricing Tables</a> </li>
                                            <li> <a href="testimonials.html">Testimonials</a> </li>
                                            <li> <a href="coming-soon.html">Coming soon</a> </li>
                                            <li> <a href="faq.html">faq</a> </li>
                                            <li> <a href="404.html">404 page</a> </li>
                                        </ul>
                                    </li>
                                    <li><a href="contact-us.html">Contact us</a></li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- –––––––––––––––[ HEADER ]––––––––––––––– -->

		<!-- –––––––––––––––[ PAGE CONTENT ]––––––––––––––– -->
		<main id="mainContent" class="main-content">
			<!-- Start Hero Area -->
            <section class="section breadcrumb-area pt-100 pb-80" data-bg-img="assets/images/slider/01.jpg">
                <div class="container t-center">
                    <div class="row">
                        <div class="col-md-10 col-md-offset-1 col-xs-12 text-center">
                            <div class="section-top-title">
                                <h1 class="t-uppercase font-45">404</h1>
                                <ol class="breadcrumb">
                                    <li><a href="index.html"><i class="fa fa-home mr-10"></i>Home</a></li>
                                    <li class="active">404</li>
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- End Hero Area -->

		    <!-- Start 404 Area  -->
			<section class="section error-404-area">
            	<div class="container">
			        <div class="row">
			            <div class="col-md-7 t-center t-md-left pt-60">
			                <div class="not-found-content">
			                    <h1 class="mb-20">404</h1>
			                    <h2 class="t-uppercase mb-30">Oops! Page Not Found</h2>
			                    <p class="color-mid mb-15">Oopps! We can’t seems to find the page you are looking for.</p>
			                    <p class="color-mid mb-15">It may be temporarily unavailable, moved or no longer exist.</p>
			                    <p class="color-mid mb-40">Check the URL you entered for any mistakes and try again.</p>
			                    <a href="index.html" class="btn btn-lg">Back To Home</a>
			                </div>
			            </div>
			            <div class="col-md-5 pt-40">
			            	<img src="assets/images/404.jpg" alt="">
			            </div>
			        </div>
			    </div>
	        </section>
	        <!-- End 404 Area  -->


		</main>
		<!-- –––––––––––––––[ END PAGE CONTENT ]––––––––––––––– -->

		<!-- –––––––––––––––[ FOOTER ]––––––––––––––– -->
		<footer class="main-footer pt-60">
		    <div class="container">
		        <div class="footer-widgets">
		            <div class="row row-masnory">
		                <div class="col-md-3 col-sm-6 pb-50">
		                    <div class="widget">
		                        <h2>About us</h2>
		                        <p class="mb-10">Vivamus sem massa, cursus at mollis eu, euismod id risus. Vestibulum nunc ante, sagittis ut nisl at, porta porttitor justo. Nam imperdiet imperdiet volutpat. Sed vitae quam congue.</p>
		                        <ul class="social-icons list-inline">
		                            <li class="social-icons__item pt-10"><a href="#"><i class="fa fa-facebook"></i></a></li>
		                            <li class="social-icons__item pt-10"><a href="#"><i class="fa fa-twitter"></i></a></li>
		                            <li class="social-icons__item pt-10"><a href="#"><i class="fa fa-linkedin"></i></a></li>
		                            <li class="social-icons__item pt-10"><a href="#"><i class="fa fa-google-plus"></i></a></li>
		                            <li class="social-icons__item pt-10"><a href="#"><i class="fa fa-pinterest"></i></a></li>
		                        </ul>
		                    </div>
		                </div>
		                <div class="col-md-3 col-sm-6 pb-50">
		                    <div class="widget">
		                        <h2>Twitter Feed</h2>
		                        <div class="twitter-widget">
		                            <div class="single_twitter">
		                                <p class="mb-15"><a href="#" class="color-theme">@CODASTROID :</a> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus pretium orci sit amet mi ullamcorper egestas. Sed non mattis metus.</p>
		                            </div>
		                            <div class="single_twitter">
		                                <p class="mb-15"><a href="#" class="color-theme">@CODASTROID :</a> Integer vel lorem tincidunt, pharetra eros nec, posuere odio. Nullam eget bibendum sem.</p>
		                            </div>
		                        </div>
		                    </div>
		                </div>
		                <div class="col-md-3 col-sm-6 pb-50">
		                    <div class="widget instagram-widget">
		                        <h2>Instagram widget</h2>
		                        <div class="row row-tb-5 row-rl-5">
		                            <div class="col-xs-4">
		                                <a href="#"><img src="assets/images/instagram/1.jpg" alt=""></a>
		                            </div>
		                            <div class="col-xs-4">
		                                <a href="#"><img src="assets/images/instagram/2.jpg" alt=""></a>
		                            </div>
		                            <div class="col-xs-4">
		                                <a href="#"><img src="assets/images/instagram/3.jpg" alt=""></a>
		                            </div>
		                            <div class="col-xs-4">
		                                <a href="#"><img src="assets/images/instagram/4.jpg" alt=""></a>
		                            </div>
		                            <div class="col-xs-4">
		                                <a href="#"><img src="assets/images/instagram/5.jpg" alt=""></a>
		                            </div>
		                            <div class="col-xs-4">
		                                <a href="#"><img src="assets/images/instagram/6.jpg" alt=""></a>
		                            </div>
		                        </div>
		                    </div>
		                </div>
		                <div class="col-md-3 col-sm-6 pb-50">
		                    <div class="widget get-in-touch">
		                        <h2>Opening Hours</h2>
		                        <ul class="opening-hours">
                                    <li>Monday – Thursday <span class="float-right">8.00 – 17.00</span></li>
                                    <li>Friday <span class="float-right">9.30 – 17.30</span></li>
                                    <li>Saturday <span class="float-right">9.30 – 15.00</span></li>
                                    <li>Sunday <span class="float-right">Closing</span></li>
                                </ul>
		                    </div>
		                </div>
		            </div>
		        </div>
		    </div>
		    <div class="sub-footer">
		        <div class="container">
		            <h6 class="copyright"> iMedical © Copyright 2015. All rights reserved. </h6>
		        </div>
		    </div>
		</footer>
        <!-- –––––––––––––––[ END FOOTER ]––––––––––– -->

    </div>
    <!-- ––––––––––––––––––––––––––––––––––––––––– -->
	<!-- END WRAPPER                               -->
	<!-- ––––––––––––––––––––––––––––––––––––––––– -->


    <!-- ––––––––––––––––––––––––––––––––––––––––– -->
	<!-- BACK TO TOP                               -->
	<!-- ––––––––––––––––––––––––––––––––––––––––– -->
	<div id="backTop" class="back-top is-hidden-sm-down">
		<i class="fa fa-angle-up" aria-hidden="true"></i>
	</div>

	<div class="layout-options">
        <div class="box-layout">
            <a href="#" id="rtl-link" class="btn btn-block">Switch To RTL</a><br><a href="https://themeforest.net/item/health-medical-dentist-doctor-clinic-and-hospital-template-imedical/19747019?ref=CODASTROID" class="btn btn-block buy-btn">Buy Now</a>
        </div>
        <div class="icon-cog">
            <i class="fa fa-cog lay fa-spin"></i>
        </div>
    </div>

	<!-- ––––––––––––––––––––––––––––––––––––––––– -->
	<!-- SCRIPTS                                   -->
	<!-- ––––––––––––––––––––––––––––––––––––––––– -->

	<!-- (!) Placed at the end of the document so the pages load faster -->

	<!-- =========[ jQuery library ]========= -->
	<script src="assets/js/jquery-1.12.3.min.js"></script>

	<!-- ========[ Latest Bootstrap ]======== -->
	<script type="text/javascript" src="assets/js/bootstrap.min.js"></script>

	<!-- ========[ JavaScript Plugins ]======== -->
	<!-- (!) Include all compiled plugins (below), or include individual files as needed -->

	<!-- Owl Carousel -->
	<script type="text/javascript" src="assets/vendors/owl-carousel/owl.carousel.min.js"></script>

	<!-- Magnific popup -->
	<script type="text/javascript" src="assets/vendors/magnific-popup/js/jquery.magnific-popup.min.js"></script>

	<!-- jQuery Easing v1.3 -->
	<script type="text/javascript" src="assets/vendors/jquery.easing.1.3.min.js"></script>

	<!-- MixItUp v2.1.11 -->
	<script type="text/javascript" src="assets/vendors/jquery.mixitup.js"></script>

	<!-- Bootstrap Datepicker -->
	<script type="text/javascript" src="assets/vendors/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>

	<!-- YTPlayer -->
    <script type="text/javascript" src="assets/vendors/YTPlayer/js/jquery.mb.YTPlayer.min.js"></script>

	<!-- =====[ Custom Template JavaScript ]===== -->
	<script type="text/javascript" src="assets/js/main.js"></script>
	<script type="text/javascript" src="assets/js/demo.js"></script>
</body>

</html>